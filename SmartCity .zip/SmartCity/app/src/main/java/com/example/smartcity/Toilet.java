package com.example.smartcity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Toilet extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner spinner;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toilet);
        spinner = findViewById(R.id.spinner);
        textView = findViewById(R.id.textView);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.ward, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String choice = parent.getItemAtPosition((int) id).toString();
        if(choice.contentEquals("ward 32"))
        {
            textView.setText("Washroom Location: atal khel\n" + "Washroom Location: nayi sadak");
        }
        if(choice.contentEquals("ward 41"))
        {
            textView.setText("Washroom Location: bapat square\n" + "Washroom Location: maruti nagar");
        }
        if(choice.contentEquals("ward 23"))
        {
            textView.setText("Washroom Location: Rambagh\n" + " Washroom Location: Narayan bagh");
        }
        if(choice.contentEquals("ward 33"))
        {
            textView.setText("Washroom Location: rajwada\n" + "Washroom Location: navelty\n"  + "Washroom Location: gandhi hall");
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}