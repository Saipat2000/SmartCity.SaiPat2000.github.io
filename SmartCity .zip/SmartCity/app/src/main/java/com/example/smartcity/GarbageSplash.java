package com.example.smartcity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class GarbageSplash extends AppCompatActivity {

    ImageView truck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_garbage_splash);

        truck = findViewById(R.id.truck);

        //Animations
        Animation animation = AnimationUtils.loadAnimation(GarbageSplash.this,R.anim.truck_animation);

        truck.setAnimation(animation);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(GarbageSplash.this,Register.class));
                finish();
            }
        },5000);

    }
}