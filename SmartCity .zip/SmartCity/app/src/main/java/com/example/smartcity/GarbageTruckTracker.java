package com.example.smartcity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class GarbageTruckTracker extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner spinner;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_garbage_truck_tracker);
        spinner = findViewById(R.id.spinner);
        textView = findViewById(R.id.textView);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.ward, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String choice = parent.getItemAtPosition((int) id).toString();
        if(choice.contentEquals("ward 32"))
        {
            textView.setText(
                    " Truck timmings: 7am-8am\n" +
                            " Truck Route: atal khel-nayi sadak-\n" +
                            "sch78.");
        }
        if(choice.contentEquals("ward 41"))
        {
            textView.setText(" Truck timmings: 12 pm-1 pm\n" +
                    "Truck route: bapat square - maruti nagar -iti");
        }
        if(choice.contentEquals("ward 23"))
        {
            textView.setText(
                    " Truck timmings: 7am-8am\n" +
                            " Truck Route: atal khel-nayi sadak-sch78.");
        }
        if(choice.contentEquals("ward 33"))
        {
            textView.setText(" Truck timmings: 5pm-6pm\n" +
                    "Truck route:  rajwada- navelty- gandhi hall");
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}