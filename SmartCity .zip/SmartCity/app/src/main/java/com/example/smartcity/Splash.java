package com.example.smartcity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class Splash extends AppCompatActivity {
    ImageView indore;
    TextView textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        indore = findViewById(R.id.indore);
        textView2 = findViewById(R.id.textView2);

        //Animations
        Animation img_anim = AnimationUtils.loadAnimation(Splash.this,R.anim.top_animation);
        Animation txt_anim = AnimationUtils.loadAnimation(Splash.this,R.anim.bottom_animation);

        indore.setAnimation(img_anim);
        textView2.setAnimation(txt_anim);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(Splash.this,GarbageSplash.class));
                finish();
            }
        },5000);

    }
}