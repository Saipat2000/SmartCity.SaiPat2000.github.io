package com.example.smartcity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Dashboard extends AppCompatActivity {
    ImageView litterbin,gtruck,washroom,complaint;
    TextView litterbintext,gtrucktext,washroomtext,complainttext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        litterbin = findViewById(R.id.litterbin);
        litterbintext = findViewById(R.id.litterbintext);
        gtruck = findViewById(R.id.gtruck);
        gtrucktext = findViewById(R.id.gtrucktext);
        washroom = findViewById(R.id.washroom);
        washroomtext = findViewById(R.id.washroomtext);
        complaint = findViewById(R.id.complaint);
        complainttext = findViewById(R.id.complainttext);

        litterbin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Dashboard.this, DustbinTracker.class);
                startActivity(i);
            }
        });
        litterbintext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Dashboard.this, DustbinTracker.class);
                startActivity(i);
            }
        });

        gtruck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Dashboard.this, GarbageTruckTracker.class);
                startActivity(i);
            }
        });
        gtrucktext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Dashboard.this, GarbageTruckTracker.class);
                startActivity(i);
            }
        });

        washroom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Dashboard.this, Toilet.class);
                startActivity(i);
            }

        });
        washroomtext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Dashboard.this, Toilet.class);
                startActivity(i);
            }

        });

        complaint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Dashboard.this, Complaint.class);
                startActivity(i);
            }

        });
        complainttext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Dashboard.this, Complaint.class);
                startActivity(i);
            }

        });
    }
}